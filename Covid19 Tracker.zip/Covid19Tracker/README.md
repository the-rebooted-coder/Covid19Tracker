[![License: MIT](https://img.shields.io/badge/License-MIT-success.svg)][![Open Source Love](https://badges.frapsoft.com/os/v2/open-source.svg?v=103)](https://github.com/ellerbrock/open-source-badges/)
# Covid19Tracker
## This is and Android Studio Package which displays vital information of Covid19 
###### Using this app the User can see all the information related to the Novel Pandemic using 3 Simple Windows
The primary purpose is to update the user about the changes happening in and around him with Real Time Information
<img src="https://github.com/the-rebooted-coder/Covid19Tracker/blob/master/app/Splash%20Screen.png" width="200">
<img src="https://github.com/the-rebooted-coder/Covid19Tracker/blob/master/app/Detailed%20Information.png" width="200">
<img src="https://github.com/the-rebooted-coder/Covid19Tracker/blob/master/app/Indian%20Dashboard.png" width="200">
<img src="https://github.com/the-rebooted-coder/Covid19Tracker/blob/master/app/Simple%20UI.png" width="200">
